document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent form submission

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    const errorMsg = document.getElementById('errorMsg');

    if (!email || !password) {
        errorMsg.textContent = "Please enter both email and password.";
        return;
    }

    // Example login check
    if (email == "pglife.@com" && password == "1234") {
        errorMsg.style.color = "green";
        errorMsg.textContent = "Login successful!";
        // Redirect to dashboard or another page
        // window.location.href = "dashboard.html";
    } else {
        errorMsg.style.color = "red";
        errorMsg.textContent = "Invalid email or password.";
    }
});
